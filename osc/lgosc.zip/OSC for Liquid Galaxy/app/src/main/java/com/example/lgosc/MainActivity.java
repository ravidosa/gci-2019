package com.example.lgosc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.IOException;
import java.net.*;

import com.illposed.osc.*;

public class MainActivity extends AppCompatActivity {
    private String myIP = "192.168.86.250";
    private int myPort = 5005;
    private OSCPortOut oscPortOut;
    private MyTask Mytask;
    private String arg;


    public void Shanghai(View view)  {
        arg="Shanghai";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void Mumbai(View view)  {
        arg="Mumbai";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void SaoPaulo(View view)  {
        arg="SaoPaulo";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void SanFransisco(View view)  {
        arg="SanFransisco";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void MexicoCity(View view)  {
        arg="Mexico City";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void Tokyo(View view)  {
        arg="Tokyo";
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void Search(View view)  {
        EditText search = (EditText)findViewById(R.id.search_input);
        arg=search.getText().toString();
        Mytask=new MyTask();
        Mytask.execute();
    }

    public void ChangeIP(View view)  {
        EditText search = (EditText)findViewById(R.id.search_input2);
        myIP=search.getText().toString();
        Mytask=new MyTask();
        Mytask.execute();
    }
    public void ChangePort(View view)  {
        EditText search = (EditText)findViewById(R.id.search_input3);
        myPort= Integer.parseInt(search.getText().toString());
        Mytask=new MyTask();
        Mytask.execute();
    }

    public class MyTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                // Connect to some IP address and port
                oscPortOut = new OSCPortOut(InetAddress.getByName(myIP), myPort);
            } catch (UnknownHostException e) {
                e.printStackTrace();
                // Error handling when your IP isn't found
            } catch (Exception e) {
                // Errorhandling for any other errors
            }
            try {
                OSCMessage message= new OSCMessage("/flyto");
                message.addArgument(arg);
                oscPortOut.send(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
