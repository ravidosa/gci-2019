package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Modern extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_modern, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("+37.7993° N, -122.3977°");
        infoRef.setValue("Another earthquake in 1989 caused destruction and death in the Bay Area, but once again, San Fransisco was able to rebuild, revitalizing Hayes Valley and The Embarcadero. In recent years, the rise of the internet industry has birthed several startups, and technology and entrepreneurship remain staples of the economy.");

        return view;
    }
}