package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Colonial extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_colonial, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("+37.7644°, -122.4269°");
        infoRef.setValue("San Francisco was inhabited by the Ohlone before being colonized by Spaniards. After their arrival, the Spanish established the mission San Francisco de Asis in the new Presidio of San Francisco. After Mexico gained independence from Spain, William Richardson and Alcalde Fransisco de Haro founded the town of Yerba Buena, attracting American settlers. During the Mexican-American war, Yerba Buena was ceded to the United States and renamed San Fransisco.");

        return view;
    }
}