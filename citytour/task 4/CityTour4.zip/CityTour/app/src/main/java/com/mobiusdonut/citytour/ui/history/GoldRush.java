package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class GoldRush extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_goldrush, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("+33.4490°, -112.0758°");
        infoRef.setValue("The California Gold Rush in 1849 led to a massive population boom for San Fransisco, leading to the construction of a harbor. After California gained statehood, several entrepreneurs founded companies like Wells Fargo, Levi’s, and Ghirardelli, and the growing population necessitated the building of the Pacific Railroad. A significant percentage of the new inhabitants were Asian, and had immigrated to work on the railroad. By 1901, San Fransisco had become a major American city.");

        return view;
    }
}