package com.mobiusdonut.citytour.ui.landing;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class LandingFragment extends Fragment {

    private LandingViewModel landingViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.fragment_landing, container, false);

        return view;
    }
}