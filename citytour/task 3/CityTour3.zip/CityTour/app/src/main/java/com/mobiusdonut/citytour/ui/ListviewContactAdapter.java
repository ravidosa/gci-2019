package com.mobiusdonut.citytour.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.mobiusdonut.citytour.R;

import androidx.recyclerview.widget.RecyclerView;

public class ListviewContactAdapter extends BaseAdapter {
    private static String[] mobileArray;

    private LayoutInflater mInflater;

    public ListviewContactAdapter(Context photosFragment, String[] results){
        mobileArray = results;
        mInflater = LayoutInflater.from(photosFragment);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return mobileArray.length;
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return mobileArray[arg0];
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        return arg0;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        RecyclerView.ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_fragment, null);
        }

        return convertView;
    }
}
