package com.mobiusdonut.citytour.ui.attractions;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Fillmore extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_fillmore, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("37.7839° N, 122.4331° W");
        infoRef.setValue("The Fillmore is a historic theater that first hosted Janis Joplin and Led Zeppelin, amongst other acts. Today, it a tourist hot spot with frequent shows.");

        return view;
    }
}