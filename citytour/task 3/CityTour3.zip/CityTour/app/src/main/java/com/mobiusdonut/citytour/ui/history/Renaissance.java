package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Renaissance extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_renaissance, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("37.7609° N, 122.4350° W");
        infoRef.setValue("In the mid-1900s, the suburbs of San Fransisco grew rapidly, with an increasing wave of immigration from Asia and Latin America countering a exodus of the white population. San Fransisco became a beacon of counterculture, with the San Fransisco Renaissance and the Summer of Love in 1967, and also became a center of the gay rights movement.");

        return view;
    }
}