package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Depression extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_depression, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("37.8199° N, 122.4783° W");
        infoRef.setValue("San Fransisco grew further as a financial capital, and remained afloat during the Great Depression. It was also during this time that the Golden Gate Bridge and San Fransisco-Oakland Bay Bridge were built. During World War II, several African Americans moved to San Fransisco due to an explosion in jobs, and the Treaty of San Fransisco ended the war with Japan.");

        return view;
    }
}