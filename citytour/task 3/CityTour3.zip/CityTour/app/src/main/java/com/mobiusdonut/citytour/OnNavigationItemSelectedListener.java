package com.mobiusdonut.citytour;

@interface OnNavigationItemSelectedListener {
}
