package com.mobiusdonut.citytour.ui;

import java.util.HashMap;
import java.util.Map;

public class Listing {
    public String location;
    public String information;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Listing() {
    }

    public Listing(String location, String information) {
        this.location = location;
        this.information = information;
    }

    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("location", location);
        result.put("information", information);
        return result;
    }
}
