package com.mobiusdonut.citytour.ui.attractions;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mobiusdonut.citytour.R;
import com.mobiusdonut.citytour.ui.Listing;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import static android.content.ContentValues.TAG;

public class SFMOMA extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_sfmoma, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("37.7857° N, 122.4011° W");
        infoRef.setValue("The San Fransisco Museum of Modern Art houses 20th century and contemporary art. It attracts more than 600,000 visitors annually.");

        return view;
    }
}