package com.example.citytour;

@interface OnNavigationItemSelectedListener {
}
