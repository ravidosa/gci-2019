package com.example.citytour.ui.landing;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class LandingViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public LandingViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is landing fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}