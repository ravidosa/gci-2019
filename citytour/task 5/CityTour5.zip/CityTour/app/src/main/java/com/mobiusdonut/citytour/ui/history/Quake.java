package com.mobiusdonut.citytour.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobiusdonut.citytour.R;

import androidx.fragment.app.Fragment;

public class Quake extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        container.clearDisappearingChildren();
        View view = inflater.inflate(R.layout.activity_quake, container, false);

        final FirebaseDatabase database = FirebaseDatabase.getInstance("https://citytour-ca745.firebaseio.com");
        final DatabaseReference myRef = database.getReference();
        final DatabaseReference locRef = myRef.child("location");
        final DatabaseReference infoRef = myRef.child("information");
        database.goOnline();
        locRef.keepSynced(true);
        infoRef.keepSynced(true);
        locRef.setValue("+37.7879°, -122.4034°");
        infoRef.setValue("A massive earthquake in 1906 killed several hundreds of people and left thousands more homeless, with many people moving to the East Bay. However, the city was rapidly rebuilt, and celebrated its rebirth at the Panama-Pacific International Exposition.");

        return view;
    }
}